DEMO PURPOSE ONLY

This demo folder should be deleted on production.

You can use any demo image/file in your project - in this case, we recommend to move only the file you need to your custom folder (example: assets/images/custom/)